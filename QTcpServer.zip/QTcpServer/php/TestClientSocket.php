<?php
include "./ClientSocket.class.php"
function readMemory() {
	$client = new Socket("127.0.0.1", 18001);
	$client.request("");
}
?>