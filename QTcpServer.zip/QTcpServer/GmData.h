﻿#ifndef GMDATA_H
#define GMDATA_H
#include <QObject>

class GmData : public QObject
{
    Q_OBJECT

public:
    GmData();

    QString testSendValue();
//    QString readSharedMemoryFromFile(const QString &sharedKey,
//                                             const QString &strPath,
//                                             uint32 nStartpos=0,
//                                             uint32 nEndpos=1);
    QString readSharedMemory(const QString &sharedKey,
                                     uint32 nStartpos=0,
                                     uint32 nEndpos=-1);

    QString readHistoryDataToMemory(const QString &strTime,
                                       uint32 startPos,
                                       const QString & strHistfile);
    QString readHistoryDataByGroupsPosAndPoints(const QString &strHistfile,
                                                   const QString &strTime,
                                                   const QString &strGroupVector,
                                                   uint32 nPos,
                                                   const QString &strPointVector,
                                                   uint32 nPointeCount);

    QString searchPosOfHistoryData(uint32 startTime, uint32 endTime, const QString &strIndexPath);
    QString readTcpipStatus(const QStringList &strSharedKeys, const QStringList &strSharedCount);
    QString readSerialPortStatus(const QStringList &sharedKeyList,
                                 const QStringList &sharedKeyCountList);
    QString printIndexPhpPage(const QString& strIndexPath, uint32 start, uint32 end);
    QString printIndexPhpPageEx(const QString &strIndexPath, uint32 start, uint32 end);
    QString getIndexPhpPage(const QString & strIndexPath, uint32 start, uint32 end);
    QString readStatus(const QString &strConfigPath, const QString &strSharedKey,
                               const QStringList& keysList,
                               const QStringList &countList);
    QString readWarning(const QString &strIndexPath, uint32 start, uint32 end, const QString &strGroup);
    QString readWarningDataToMemory(uint32 nPos, const QString &strHistFile);
};

#endif // GMDATA_H
