﻿#include "PhpTcpServer.h"
#include <QTcpSocket>

PhpTcpServer::PhpTcpServer(unsigned short port, QObject *parent) :
    QObject(parent)
{
    m_pTcpServer = new QTcpServer();
    connect(m_pTcpServer, &QTcpServer::newConnection, this, &PhpTcpServer::onNewConnection);
    connect(m_pTcpServer, &QTcpServer::acceptError, this, &PhpTcpServer::onAcceptError);
    if (!m_pTcpServer->listen(QHostAddress::Any, port)) {
        qDebug() << "m_pTcpServer->listen() error";
        assert(false);
    } else {
        qDebug() <<"start listen:" << port;
    }
}

void PhpTcpServer::onNewConnection()
{
    QTcpSocket* pClientConnection = m_pTcpServer->nextPendingConnection();
    if (pClientConnection) {
        connect(pClientConnection, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
    }
}

void PhpTcpServer::onAcceptError(QAbstractSocket::SocketError socketError)
{
    qDebug() << "SimpleTcpSocketServerDemo::displayError " << socketError;
}

void PhpTcpServer::onReadyRead()
{
    QTcpSocket* pClientConnection = dynamic_cast<QTcpSocket*>(sender());
    QString data = pClientConnection->readAll();
    QStringList list = data.split("&");
    if (list.length()>0) {
        QString ret = "";
        if (list[0].compare("testSendValue", Qt::CaseInsensitive) == 0) {
            ret = m_gmData.testSendValue();
        } else if (list[0].compare("readSharedMemoryFromFile", Qt::CaseInsensitive) == 0) {
            QString sharedKey = list.length()>1?list[1]:"";
            QString strPath = list.length()>2?list[2]:"";
            uint32 nStartpos = list.length()>3?list[3].toUInt():0;
            uint32 nEndpos = list.length()>4?list[4].toUInt():-1;
            ret = m_gmData.readSharedMemoryFromFile(sharedKey, strPath, nStartpos, nEndpos);
        } else if (list[0].compare("readSharedMemory", Qt::CaseInsensitive) == 0) {
            QString sharedKey = list.length()>1?list[1]:"";
            uint32 nStartpos = list.length()>2?list[2].toUInt():0;
            uint32 nEndpos = list.length()>3?list[3].toUInt():-1;
            ret = m_gmData.readSharedMemory(sharedKey, nStartpos, nEndpos);
        } else if (list[0].compare("readHistoryDataToMemory", Qt::CaseInsensitive) == 0) {
            QString strTime = list.length()>1?list[1]:"";
            uint32 startPos = list.length()>2?list[2].toUInt():0;
            QString strHistfile = list.length()>3?list[3].toUInt():-1;
            ret = m_gmData.readHistoryDataToMemory(strTime, startPos, strHistfile);
        } else if (list[0].compare("readHistoryDataByGroupsPosAndPoints", Qt::CaseInsensitive) == 0) {
            QString strHistfile = list.length()>1?list[1]:"";
            QString strTime = list.length()>2?list[2]:"";
            QString strGroupVector = list.length()>3?list[3]:"";
            uint32 nPos = list.length()>4?list[4].toUInt():0;
            QString strPointVector = list.length()>5?list[5]:"";
            uint32 nPointeCount = list.length()>6?list[6].toUInt():0;
            ret = m_gmData.readHistoryDataByGroupsPosAndPoints(strHistfile, strTime, strGroupVector,
                                                               nPos, strPointVector, nPointeCount);
        } else if (list[0].compare("searchPosOfHistoryData", Qt::CaseInsensitive) == 0) {
            uint32 startTime = list.length()>1?list[1].toUInt():0;
            uint32 endTime = list.length()>2?list[2].toUInt():0;
            QString strIndexPath = list.length()>3?list[3]:"";
            ret = m_gmData.searchPosOfHistoryData(startTime, endTime, strIndexPath);
        } else if (list[0].compare("readTcpipStatus", Qt::CaseInsensitive) == 0) {
            QStringList strSharedKeys = list.at(1).split("|");
            QStringList strSharedCount = list.at(2).split("|");
            ret = m_gmData.readTcpipStatus(strSharedKeys, strSharedCount);
        } else if (list[0].compare("readSerialPortStatus", Qt::CaseInsensitive) == 0) {
            QStringList strSharedKeys = list.at(1).split("|");
            QStringList strSharedCount = list.at(2).split("|");
            ret = m_gmData.readSerialPortStatus(strSharedKeys, strSharedCount);
        } else if (list[0].compare("printIndexPhpPage", Qt::CaseInsensitive) == 0) {
            QString strIndexPath = list.at(1);
            uint32 start = list.at(2).toUInt();
            uint32 end = list.at(3).toUInt();
            ret = m_gmData.printIndexPhpPage(strIndexPath, start, end);
        } else if (list[0].compare("printIndexPhpPageEx", Qt::CaseInsensitive) == 0) {
            QString strIndexPath = list.at(1);
            uint32 start = list.at(2).toUInt();
            uint32 end = list.at(3).toUInt();
            ret = m_gmData.printIndexPhpPageEx(strIndexPath, start, end);
        } else if (list[0].compare("getIndexPhpPage", Qt::CaseInsensitive) == 0) {
            QString strIndexPath = list.at(1);
            uint32 start = list.at(2).toUInt();
            uint32 end = list.at(3).toUInt();
            ret = m_gmData.getIndexPhpPage(strIndexPath, start, end);
        } else if (list[0].compare("readStatus", Qt::CaseInsensitive) == 0) {
            QString strConfigPath = list.at(1);
            QString strSharedKey = list.at(2);
            QStringList keysList = list.at(3).split("|");
            QStringList countList = list.at(4).split("|");
            ret = m_gmData.readStatus(strConfigPath, strSharedKey, keysList, countList);
        } else if (list[0].compare("readWarning", Qt::CaseInsensitive) == 0) {
            QString strIndexPath = list.at(1);
            uint32 start = list.at(2).toUInt();
            uint32 end = list.at(3).toUInt();
            QString strGroup = list.at(4);
            ret = m_gmData.readWarning(strIndexPath, start, end, strGroup);
        } else if (list[0].compare("readWarningDataToMemory", Qt::CaseInsensitive) == 0) {
            uint32 nPos = list.at(1).toUInt();
            QString strHistFile = list.at(2);
            ret = m_gmData.readWarningDataToMemory(nPos, strHistFile);
        } else {
            ret = "can not find function " + list[0] + data;
        }

        if (ret.length() > 0) {
            pClientConnection->write(ret.toStdString().c_str());
        }
    }
    qDebug()<<"got:"<<data<<"from client"<<endl;

    pClientConnection->flush();
    pClientConnection->close();
}

PhpTcpServer::~PhpTcpServer()
{
    if (m_pTcpServer) {
        m_pTcpServer->close();
        m_pTcpServer->deleteLater();
        m_pTcpServer = nullptr;
    }
}
