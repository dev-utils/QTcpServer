﻿#ifndef TCPSERVER_H
#define TCPSERVER_H

#include <QTcpServer>
#include "GmData.h"

class PhpTcpServer : public QObject
{
    Q_OBJECT
public:
    PhpTcpServer(unsigned short port, QObject *parent=0);
    ~PhpTcpServer();

private slots:
    void onNewConnection();

    void onAcceptError(QAbstractSocket::SocketError socketError);
    void onReadyRead();

private:
    QTcpServer *m_pTcpServer = nullptr;
    GmData m_gmData;
};

#endif // TCPSERVER_H
