﻿#include "GmData.h"
#include <iostream>
#include <stdlib.h>
#include <stdio.h>

#include "phpgm.h"
#include "MemHeap.h"
#include "config.h"
#include "StatusReporter.h"
#include "HistoryDataHelper.h"

#include "QTextStream"
#include <QDir>
#include <QDate>
#include "mylog.h"
#include "timetrans.h"
#include "Warning.h"
#include "outdatecheck.h"


GmData::GmData()
{
}

QString GmData::testSendValue()
{
   return "apple|banana|tomato&hello|world|love";
}

//QString GmData::readSharedMemoryFromFile(const QString &sharedKey,
//                                         const QString &strPath,
//                                         uint32 nStartpos,
//                                         uint32 nEndpos)
//{
//    QString ret = "";
//    char shared_key[512] = {0};
//    strcpy(shared_key, sharedKey.toStdString().c_str());
//    printf("%s\n", shared_key);

//    //get data path
//    char path[MAX_PATH] = {0};
//    strcpy(path, strPath.toStdString().c_str());

//    char* srcPtr = NULL;
//    size_t len = 0;

//    if (MemHeap::readSharedMemoryDataFromFile(shared_key, path, &srcPtr, &len) == false) {
//        ret += "read file error";
//        ret += "&";
//        ret += strerror(errno);
//        ret += "&";
//        ret += path;
//        ret += "&";
//        ret += shared_key;
//        ret += "&";
//        ret += strerror(errno);
//        if(srcPtr != NULL){
//            free(srcPtr);
//            srcPtr = NULL;
//        }
//        return ret;
//    }

//    int index = 0;
//    char tmp[64];
//    char *ptr = srcPtr;

//    printf("shered memory size is %u\n", len);

//    MYTIME_T tt = *(MYTIME_T*)ptr;
//    ptr += sizeof(MYTIME_T);
//    uint32 size = *(uint32*)ptr;
//    ptr += sizeof(uint32);

//    bool good = true;
//    uint32 spos = nStartpos;
//    uint32 epos = size - 1;
//    if (nEndpos != -1) {
//        epos = nEndpos;
//        if (spos > epos || spos >= size || epos >= size) {
//            good = false;
//        }
//    }

//    if (good) {
//        _snprintf_s(tmp, 64, _TRUNCATE, "%lu", tt);
//        //arrayDatas[index++] = tmp;
//        ret += tmp;
//        //printf("%s\n", tmp);
//        _snprintf_s(tmp, 64, _TRUNCATE, "%lu", size);
//        ret += "&";
//        ret += tmp;
//        //arrayDatas[index++] = tmp;
//        //printf("%s\n", tmp);

//        DataStructure* ds = (DataStructure*)ptr;
//        ds += spos;
//        for (uint32 i = spos; i <= epos; ++i, ++ds) {
//            if (ds->datatype == POINT_DATATYPE_TYPE_ANALOG)
//                _snprintf_s(tmp, 64, _TRUNCATE, "%.02f", ds->data.fvalue);
//            else
//                _snprintf_s(tmp, 64, _TRUNCATE, "%d", ds->data.bvalue);
//            //arrayDatas[index++] = tmp;
//            ret += "&";
//            ret += tmp;
//            ret += "&";
//        }
//    }
//    if(srcPtr != NULL){
//        free(srcPtr);
//        srcPtr = NULL;
//    }
//    return ret;
//}

QString GmData::readSharedMemory(const QString &sharedKey,
                                 uint32 nStartpos,
                                 uint32 nEndpos)
{
    QStringList arrayDatas;
    char shared_key[512] = {0};
    strcpy(shared_key, sharedKey.toStdString().c_str());
    printf("%s\n", shared_key);

    MemHeap* mh = new MemHeap(shared_key, MEMDATA_ACCESS_MODE_READONLY, 0);
    printf("new %s\n", (mh) ? "OK" : "FALIED");

    int result = mh->openMemData();

    if (result) {
        //cout << result << endl;
        printf("Can not open memory data\n");
        char sz[1024] = "Can not open memory data:";
        strcat(sz, shared_key);
        arrayDatas.push_back(sz);
        arrayDatas.push_back(strerror(errno));
        return arrayDatas.join("|");
    }

    MEMORY_BUFFER* mb = mh->getMemBuf();
    char* ptr = mb->bufptr;
    int index = 0;
    char tmp[64];

    printf("shered memory size is %u\n", (uint32)mb->size);

    MYTIME_T tt = *(MYTIME_T*)ptr;
    ptr += sizeof(MYTIME_T);
    uint32 size = *(uint32*)ptr;
    ptr += sizeof(uint32);

    bool good = true;
    uint32 spos = nStartpos;
    uint32 epos = size - 1;
    if (nEndpos != -1) {
        epos = nEndpos;
    }

    if (spos > epos || spos >= size || epos >= size) {
        good = false;
    }

    if (good) {
        _snprintf_s(tmp, 64, _TRUNCATE, "%lu", tt);
        arrayDatas.push_back(tmp);
        //arrayDatas[index++] = tmp;
        //printf("%s\n", tmp);
        _snprintf_s(tmp, 64, _TRUNCATE, "%lu", size);
        arrayDatas.push_back(tmp);
        //arrayDatas[index++] = tmp;
        //printf("%s\n", tmp);

        DataStructure* ds = (DataStructure*)ptr;
        ds += spos;
        for (uint32 i = spos; i <= epos; ++i, ++ds) {
            if (ds->datatype == POINT_DATATYPE_TYPE_ANALOG)
                _snprintf_s(tmp, 64, _TRUNCATE, "%.02f", ds->data.fvalue);
            else
                _snprintf_s(tmp, 64, _TRUNCATE, "%d", ds->data.bvalue);
            //arrayDatas[index++] = tmp;
            arrayDatas.push_back(tmp);
        }
    }

    delete mh;
    return arrayDatas.join("|");
}

QString GmData::readHistoryDataToMemory(const QString &strTime,
                                   uint32 startPos,
                                   const QString & strHistfile)
{
    QStringList arrayDatas;
    char time[50] = {0};
    strcpy(time, strTime.toStdString().c_str());
    uint32 pos = startPos;
    char histfile[MAX_PATH] = {0};
    strcpy(histfile, strHistfile.toStdString().c_str());

    char szDate[64] = {0};
    strcpy(szDate, time);

    char szHistFile[MAX_PATH] = {0};
    strcpy(szHistFile, histfile);

    QString strDateTime(szDate);
    int nSpaceIndex = strDateTime.indexOf(" ");
    if (nSpaceIndex<0)
    {
        printf("get datatime error %s !\n", szDate);
        arrayDatas.push_back(QString("get datatime error %1 !\n").arg(szDate));
        return arrayDatas.join("|");
    }

    strDateTime = strDateTime.left(nSpaceIndex).trimmed();
    QDate date = QDate::fromString(strDateTime, "yyyy-M-d");
    if(!date.isValid())
    {
        printf("get datatime error %s !\n", szDate);
        arrayDatas.push_back(QString("get datatime error %1 !\n").arg(szDate));
        return arrayDatas.join("|");
    }

    QString strFileName = QString(szHistFile)+"/"+date.toString("yyyy-MM-dd");
    if(!QFile::exists(strFileName))
    {
        printf("file not exist %s !\n", strFileName.toStdString().c_str());
        arrayDatas.push_back(QString("file not exist %1 !\n").arg(strFileName));
        return arrayDatas.join("|");
    }

    FILE* fp = fopen(strFileName.toStdString().c_str(), "rb");
    if (!fp)
    {
        printf("Can not open %s to read!\n", strFileName.toStdString().c_str());
        arrayDatas.push_back(QString("Can not open %1 to read !\n").arg(strFileName));
        return arrayDatas.join("|");
    }

    int result = fseek(fp, pos, SEEK_SET);
    //printf("RESULT %d\n", result);

    if (!result) {
        MYTIME_T tt;
        uint32 datanum;

        result = fread(&tt, sizeof(MYTIME_T), 1, fp);
        result = fread(&datanum, sizeof(uint32), 1, fp);

        printf("Pos %u Time %u Datanum %u\n",pos, tt, datanum);

        char tmp[64]={0};
        _snprintf_s(tmp, 64, _TRUNCATE, "%lu", tt);
        //arrayDatas[0] = tmp;
        arrayDatas += tmp;
        arrayDatas += "|";

        //arrayDatas[1]=length
        _snprintf_s(tmp, 64, _TRUNCATE, "%lu", datanum);
        //arrayDatas[1] = tmp;
        arrayDatas += tmp;
        arrayDatas += "|";

        DataStructure* buf = new DataStructure[datanum];
        result = fread(buf, sizeof(DataStructure), datanum, fp);

        //char tmp[64];
        DataStructure* ds = buf;
        for (uint32 i = 0; i < datanum; ++i, ++ds) {
            if (ds->datatype == POINT_DATATYPE_TYPE_ANALOG)
                _snprintf_s(tmp, 64, _TRUNCATE, "%.02f", ds->data.fvalue);
            else
                _snprintf_s(tmp, 64, _TRUNCATE, "%d", ds->data.bvalue);
            //arrayDatas[i+2] = tmp;
            arrayDatas.push_back(tmp);
        }

        delete[] buf;
    }
    return arrayDatas.join("&");
}

QString GmData::readHistoryDataByGroupsPosAndPoints(const QString &strHistfile,
                                               const QString &strTime,
                                               const QString &strGroupVector,
                                               uint32 nPos,
                                               const QString &strPointVector,
                                               uint32 nPointeCount)
{
//    Php::Value arrayDatas;

//    size_t numParam = params.size();
//    if (numParam != 6)
//        return arrayDatas;

    QStringList arrayDatas;
    char histfile[MAX_PATH] = {0};
    strcpy(histfile, strHistfile.toStdString().c_str());
    char time[50] = {0};
    strcpy(time, strTime.toStdString().c_str());
    std::vector<int> groupVector = strGroupVector.split("|"));
    uint32 pos = nPos;
    std::vector<int> pointVector = strPointVector.split("|");
    uint32 pointCount = nPointeCount;

    char szDate[64] = {0};
    strcpy(szDate, time);

    char szHistFile[MAX_PATH] = {0};
    strcpy(szHistFile, histfile);

    QString strDateTime(szDate);
    int nSpaceIndex = strDateTime.indexOf(" ");
    if (nSpaceIndex<0)
    {
        printf("get datatime error %s !\n", szDate);
        arrayDatas.push_back(QString("get datatime error %1 !\n").arg(szDate));
        return arrayDatas.join("|");
    }

    strDateTime = strDateTime.left(nSpaceIndex).trimmed();
    QDate date = QDate::fromString(strDateTime, "yyyy-M-d");
    if(!date.isValid())
    {
        printf("get datatime error %s !\n", szDate);
        arrayDatas.push_back(QString("get datatime error %1 !\n").arg(szDate));
        return arrayDatas.join("|");
    }

    QString strFileName = QString(szHistFile)+"/"+date.toString("yyyy-MM-dd");
    if(!QFile::exists(strFileName))
    {
        printf("file not exist %s !\n", strFileName.toStdString().c_str());
        arrayDatas.push_back(QString("file not exist %1 !\n").arg(strFileName));
        return arrayDatas.join("|");
    }

    FILE* fp = fopen(strFileName.toStdString().c_str(), "rb");
    if (!fp)
    {
        printf("Can not open %s to read!\n", strFileName.toStdString().c_str());
        arrayDatas = QString("Can not open %1 to read!\n").arg(strFileName);
        return arrayDatas;
    }

    int result = fseek(fp, pos, SEEK_SET);
    //printf("RESULT %d\n", result);

    if (!result) {
        MYTIME_T tt;
        uint32 datanum;

        result = fread(&tt, sizeof(MYTIME_T), 1, fp);
        result = fread(&datanum, sizeof(uint32), 1, fp);

        printf("Pos %u Time %u Datanum %u\n",pos, tt, datanum);

        char tmp[64]={0};
        //        _snprintf_s(tmp, 64, _TRUNCATE, "%lu", tt);
        //        arrayDatas[0] = tmp;
        //        //arrayDatas[1]=length
        //        _snprintf_s(tmp, 64, _TRUNCATE, "%lu", datanum);
        //        arrayDatas[1] = tmp;

        DataStructure* buf = new DataStructure[datanum];
        result = fread(buf, sizeof(DataStructure), datanum, fp);

        //        char s[1024]={0};
        //        //sprintf(s, "histfile=%s, time=%s,pos=%d,pointCount=%d",histfile,  time, pos, pointCount);
        //         sprintf(s, "datanum=%d",datanum);
        //        arrayDatas[0] = s;
        //        return arrayDatas;

        //char tmp[64];
        DataStructure* ds = buf;
        int nIndex = 0;
        vector<int>::iterator itGroup = groupVector.begin();
        while(itGroup != groupVector.end())
        {
            vector<int>::iterator itPoint = pointVector.begin();
            int nColumnIndex  = 0;
            //Php::Value rowData;
            QStringList rowData;
            while(itPoint != pointVector.end())
            {
                int nIndex = (*itGroup-1)*pointCount+*itPoint-1;
                itPoint++;

                strcpy(tmp, "");
                if(nIndex<(int)datanum)
                {
                    DataStructure*  dsTmp = ds + nIndex;
                    if (dsTmp->datatype == POINT_DATATYPE_TYPE_ANALOG)
                        _snprintf_s(tmp, 64, _TRUNCATE, "%.02f", dsTmp->data.fvalue);
                    else
                        _snprintf_s(tmp, 64, _TRUNCATE, "%d", dsTmp->data.bvalue);

                    arrayDatas.push_back(rowData.join("|"));
                    //arrayDatas[nColumnIndex] = tmp;
                    //nColumnIndex++;
                }
                //rowData[nColumnIndex] = tmp;
                rowData.push_back(tmp);
                nColumnIndex++;
            }
            arrayDatas.prepend(rowData.join("|"));
            //arrayDatas[nIndex] = rowData;
            nIndex++;
            itGroup++;
        }

        delete[] buf;
    }
    return arrayDatas.join("&");
}

QString GmData::searchPosOfHistoryData(uint32 startTime, uint32 endTime, const QString &strIndexPath)
{/*
    Php::Value arrayDatas;

    if (params.size() != 3) return arrayDatas;*/
    QStringList arrayDatas;
    MYTIME_T st = static_cast<MYTIME_T>(startTime);
    MYTIME_T et = static_cast<MYTIME_T>(endTime);
    // const char* datapath = Php::Value(params[2]).stringValue().c_str();
    char index_path[MAX_PATH] = {0};
    strcpy(index_path, strIndexPath.toStdString().c_str());

    int pos1, pos2;
    int count = 0;
    //search from temp-index
    FILE* fp = 0;
    if (fopen_s(&fp, index_path, "rb")) {
        arrayDatas = QString("open file %1 failed").arg(index_path);
        return arrayDatas;
    }

    MYTIME_T t = 0;
    int32   pos = 0;
    pos1 = pos2 = -1;

    bool good = true;
    while(good) {
        good = (1 == fread(&t, sizeof(MYTIME_T), 1, fp));
        if (good)
            good = (1 == fread(&pos, sizeof(int32), 1, fp));

        if (good) {
            if (t >= st && t <= et) {
                ++count;
                if (pos1 == -1)
                    pos1 = pos;
                pos2 = pos;
            }
        }
    }

    if (fp)
        fclose(fp);

    arrayDatas.push_back(QString::number(count));
    arrayDatas.push_back(QString::number(pos1));
    arrayDatas.push_back(QString::number(pos2));

//    arrayDatas[0] = count;
//    arrayDatas[1] = pos1;
//    arrayDatas[2] = pos2;

    return arrayDatas.join("|");
}


QString GmData::readTcpipStatus(const QStringList &strSharedKeys, const QStringList &strSharedCount)
{
    //Php::Value arrayDatas;
    QStringList arrayDatas;

//    size_t numParam = params.size();
//    if (numParam != 6)
//    {
//        arrayDatas[0] = "numParam != 6";
//        return arrayDatas;
//    }

    int kkk = 0;
    char shared_key[512] = {0};
    for (size_t i  = 0; i < strSharedKeys.length() && i< strSharedCount.length(); i++) {
        memset(shared_key, 0 ,sizeof(shared_key));
        strcpy(shared_key, strSharedKeys.at(i).toStdString().c_str());
        uint32 num = static_cast<uint32>(strSharedCount.at(i).toUInt());
        printf("%s %u %u\n", shared_key, num, (uint32)strlen(shared_key));
        //QByteArray ba(shared_key);
        //QString sk(ba);
        QSharedMemory sm(shared_key);
        if (!sm.attach()) {
            printf("haha Open %s error %s\n",
                   //sk.toStdString().c_str(),
                   shared_key,
                   sm.errorString().toStdString().c_str());
            char error[1024] = {0};
            sprintf(error, "%s:%s", shared_key,sm.errorString().toStdString().c_str());
            arrayDatas += error;
            arrayDatas += "|";
            //arrayDatas[i] = error;
            return arrayDatas;
        } else {
            printf("Attached %s OK!\n", shared_key);

        }

        char *buf = (char*)sm.data();
        size_t buflen = sm.size();

        if (num > buflen / sizeof(TCPIP_STATUS)
                || buflen % sizeof(TCPIP_STATUS)) {
            printf("Wrong num\n");
            //arrayDatas[0] = "Wrong num";
            arrayDatas = "Wrong num";
            return arrayDatas;
        }

        TCPIP_STATUS* status = (TCPIP_STATUS*)buf;
        status+=kkk;
        for (uint32 i = 0; i < num; ++i, ++status) {
            //printf_tcpip_status(ts);

            char timebuf[64];
            {
                time_t t = (time_t)status->LastAction;
                struct tm* tt2 = localtime(&t);

                _snprintf_s(timebuf, 64, _TRUNCATE,
                            "%04d-%02d-%02d %02d:%02d:%02d",
                            tt2->tm_year + 1900,
                            tt2->tm_mon + 1,
                            tt2->tm_mday,
                            tt2->tm_hour,
                            tt2->tm_min,
                            tt2->tm_sec);
            }

            QString stat = "";
            //Php::Value stat;
            //stat[0] = status->Name;
            stat += status->Name;
            stat += "|";

            //stat[1] = Php::Value((int32_t)status->Port);
            stat += QString::number((int32_t)status->Port);
            stat += "|";

            //stat[2] = Php::Value((status->TcpipType == TCPIP_TYPE_UDP) ? "UDP" : "TCP");
            stat += (status->TcpipType == TCPIP_TYPE_UDP) ? "UDP" : "TCP";
            stat += "|";

            //stat[3] = Php::Value((status->DirType == COMM_DIRECTION_TYPE_RECEIVED) ? "IN" : "OUT");
            stat += (status->DirType == COMM_DIRECTION_TYPE_RECEIVED) ? "IN" : "OUT";
            stat += "|";

            //stat[4] = Php::Value(timebuf);
            stat += timebuf;
            stat += "|";

            //stat[5] = Php::Value((int32_t)((MYTIME_T)time(0) - status->LastAction));
            stat += QString::number((int32_t)((MYTIME_T)time(0) - status->LastAction));
            stat += "|";

            //stat[6] = Php::Value((int32_t)status->InBytes );
            stat += QString::number((int32_t)status->InBytes);
            stat += "|";

            bool good = ((MYTIME_T)time(0) - status->LastAction > 60 * 10) ? false : true;
            //stat[7] = Php::Value((good) ? "GOOD" : "BAD");
            stat += (good) ? "GOOD" : "BAD";
            stat += "|";

            //stat[8] = Php::Value((int32_t)status->OutBytes);
            stat += QString::number((int32_t)status->OutBytes);
            stat += "|";

            //stat[9] = Php::Value((good) ? "GOOD" : "BAD");
            stat += (good) ? "GOOD" : "BAD";
            stat += "|";

            //stat[10] = (int)(status-(TCPIP_STATUS*)buf);
            stat += QString::number((int)(status-(TCPIP_STATUS*)buf));
            stat += "|";

            //stat[11] = kkk;
            stat += kkk;
            stat += "|";

            //stat[12] = (int)buflen;
            stat += QString::number((int)buflen);
            stat += "|";

            arrayDatas += stat;
            arrayDatas += "&";
            //arrayDatas[kkk++] = stat;
        }
    }
    return arrayDatas;
}

QString GmData::readSerialPortStatus(const QStringList &sharedKeyList,
                                     const QStringList &sharedKeyCountList)
{
    //Php::Value arrayDatas;
    QStringList arrayDatas;

//    size_t numParam = params.size();
//    if (numParam != 6)
//        return arrayDatas;

    int kkk = 0;
    char shared_key[512] = {0};
    for (size_t i  = 0; i < sharedKeyList.length() && i < sharedKeyCountList.length(); i++) {
        memset(shared_key, 0, sizeof(shared_key));
        strcpy(shared_key, sharedKeyList.at(i).toStdString().c_str());
        uint32 num = static_cast<uint32>(sharedKeyCountList.at(i).toUInt());
        printf("%s %u %u\n", shared_key, num, (uint32)strlen(shared_key));
        //QByteArray ba(shared_key);
        //QString sk(ba);
        QSharedMemory sm(shared_key);
        if (!sm.attach()) {
            printf("haha Open %s error %s\n",
                   //sk.toStdString().c_str(),
                   shared_key,
                   sm.errorString().toStdString().c_str());
            return arrayDatas.join("|");
        } else {
            printf("Attached %s OK!\n", shared_key);

        }

        char *buf = (char*)sm.data();
        size_t buflen = sm.size();

        if (num > buflen / sizeof(SERIAL_PORT_STATUS)
                || buflen % sizeof(SERIAL_PORT_STATUS)) {
            printf("Wrong num\n");
            return arrayDatas.join("|");
        }

        SERIAL_PORT_STATUS* status = (SERIAL_PORT_STATUS*)buf;

        for (uint32 i = 0; i < num; ++i, ++status) {
            //printf_tcpip_status(ts);

            char timebuf[64];
            {
                time_t t = (time_t)status->LastAction;
                struct tm* tt2 = localtime(&t);

                _snprintf_s(timebuf, 64, _TRUNCATE,
                            "%04d-%02d-%02d %02d:%02d:%02d",
                            tt2->tm_year + 1900,
                            tt2->tm_mon + 1,
                            tt2->tm_mday,
                            tt2->tm_hour,
                            tt2->tm_min,
                            tt2->tm_sec);
            }

            //Php::Value stat;
            QStringList stat;
            //stat[0] = status->Name;
            stat.push_back(status->Name);

            //stat[1] = Php::Value("");
            stat.push_back("");

            //stat[2] = Php::Value("");
            stat.push_back("");

            //stat[3] = Php::Value((status->DirType == COMM_DIRECTION_TYPE_RECEIVED) ? "IN" : "OUT");
            stat.push_back(status->DirType == COMM_DIRECTION_TYPE_RECEIVED) ? "IN" : "OUT");

            //stat[4] = Php::Value(timebuf);
            stat.push_back(timebuf);

            //stat[5] = Php::Value((int32_t)((MYTIME_T)time(0) - status->LastAction));
            stat.push_back(QString::number((int32_t)((MYTIME_T)time(0) - status->LastAction)));

            //stat[6] = Php::Value((int32_t)status->InBytes );
            stat.push_back(QString::number((int32_t)status->InBytes));

            bool good = ((MYTIME_T)time(0) - status->LastAction > 60 * 10) ? false : true;
            //stat[7] = Php::Value((good) ? "GOOD" : "BAD");
            stat.push_back((good) ? "GOOD" : "BAD");

            //stat[8] = Php::Value((int32_t)status->OutBytes);
            stat.push_back(QString::number((int32_t)status->OutBytes));

            //stat[9] = Php::Value((good) ? "GOOD" : "BAD");
            stat.push_back((good) ? "GOOD" : "BAD");

            //arrayDatas[kkk++] = stat;
            arrayDatas.push_back(stat.join("|"));
        }
    }
    return arrayDatas.join("&");
}

QString GmData::printIndexPhpPage(const QString& strIndexPath, uint32 start, uint32 end)
{
    //Php::Value arrayDatas;
    QStringList arrayDatas;

//    size_t numParam = params.size();
//    if (numParam != 3)
//        return arrayDatas;

    char indexpath[MAX_PATH] = {0};
    strcpy(indexpath, strIndexPath.toStdString().c_str());
    MYTIME_T st = static_cast<MYTIME_T>(start);
    MYTIME_T et = static_cast<MYTIME_T>(end);
    printf("%s %u %u\n", indexpath, st, et);

    char szIndexPath[MAX_PATH] = {0};
    strcpy(szIndexPath, indexpath);

    uint32 histno = 0;
    uint32 sn = 0;
    QList<QString> strDateList = HistoryDataHelper::getReginIndexFilesDate(st, et, indexpath);
    for (int i=0; i<strDateList.size(); i++)
    {
        QString strPath = szIndexPath + QString("/")+strDateList.at(i);//file ab path
        if (!QFile::exists(strPath))
        {
            mylog(L_ERR, "file %s not exist\n", strPath.toStdString().c_str());
            continue;
        }

        MYTIME_T theTime = 0;
        uint32   pos     = 0;
        FILE* fpIndex = NULL;
        char buf[1024] = {0};

        if (!fopen_s(&fpIndex, strPath.toStdString().c_str(), "rb"))
        {
            bool good = true;

            while(good)
            {
                if (good)
                    good = (1 == fread(&theTime, sizeof(MYTIME_T), 1, fpIndex));
                if (good)
                    good = (1 == fread(&pos    , sizeof(uint32)  , 1, fpIndex));

                if (theTime < st|| theTime > et || st > et)
                    continue;

                if (good)
                {
                    struct tm lt;
                    {
                        time_t t = (time_t)theTime;
                        localtime_s(&lt, &t);
                    }

                    ++sn;
                    _snprintf_s(buf, 1024, _TRUNCATE,
                                "\
                                <tr>\n\
                                <td>%d</td><td>%d-%d-%d %d:%d:%d</td><td><a href=\"showhistdata.php?tt=%d&index=%d&time=%d-%d-%d %d:%d:%d&pos=%u\">Show Data</a></td>\n\
                            </tr>\n",
                            sn,
                                lt.tm_year + 1900,
                                lt.tm_mon + 1,
                                lt.tm_mday,
                                lt.tm_hour,
                                lt.tm_min,
                                lt.tm_sec,
                                theTime,
                                sn,
                                lt.tm_year + 1900,
                                lt.tm_mon + 1,
                                lt.tm_mday,
                                lt.tm_hour,
                                lt.tm_min,
                                lt.tm_sec,
                                pos);
                    //arrayDatas[histno++] = buf;
                    arrayDatas.push_back(buf);
                }
            }
            fclose(fpIndex);
        } else
        {
            printf("Can not open %s\n", strPath.toStdString().c_str());
            mylog(L_ERR, "Can not open %s\n", strPath.toStdString().c_str());
        }
    }//end for

    return arrayDatas.join("|");
}

QString GmData::printIndexPhpPageEx(const QString &strIndexPath, uint32 start, uint32 end)
{
    //Php::Value arrayDatas;
    QStringList arrayDatas;

//    size_t numParam = params.size();
//    if (numParam != 3){
//        return arrayDatas;
//    }

    char indexpath[MAX_PATH] = {0};
    strcpy(indexpath, strIndexPath.toStdString().c_str());
    MYTIME_T st = static_cast<MYTIME_T>(start);
    MYTIME_T et = static_cast<MYTIME_T>(end);
    printf("%s %u %u\n", indexpath, st, et);

    char szIndexPath[MAX_PATH] = {0};
    strcpy(szIndexPath, indexpath);

    uint32 histno = 0;
    uint32 sn = 0;
    QList<QString> strDateList = HistoryDataHelper::getReginIndexFilesDate(st, et, indexpath);
    for (int i=0; i<strDateList.size(); i++)
    {
        QString strPath = szIndexPath + QString("/")+strDateList.at(i);//file ab path
        if (!QFile::exists(strPath))
        {
            mylog(L_ERR, "file %s not exist\n", strPath.toStdString().c_str());
            continue;
        }

        MYTIME_T theTime = 0;
        uint32   pos     = 0;
        FILE* fpIndex = NULL;
        char buf[1024] = {0};

        if (!fopen_s(&fpIndex, strPath.toStdString().c_str(), "rb"))
        {
            bool good = true;

            while(good)
            {
                if (good)
                    good = (1 == fread(&theTime, sizeof(MYTIME_T), 1, fpIndex));
                if (good)
                    good = (1 == fread(&pos    , sizeof(uint32)  , 1, fpIndex));

                if (theTime < st|| theTime > et || st > et)
                    continue;

                if (good)
                {
                    struct tm lt;
                    {
                        time_t t = (time_t)theTime;
                        localtime_s(&lt, &t);
                    }

                    ++sn;
                    _snprintf_s(buf, 1024, _TRUNCATE,
                                "%d_%d-%d-%d %d:%d:%d_%d_%u",
                                sn,
                                lt.tm_year + 1900,
                                lt.tm_mon + 1,
                                lt.tm_mday,
                                lt.tm_hour,
                                lt.tm_min,
                                lt.tm_sec,
                                theTime,
                                pos);
                    //arrayDatas[histno++] = buf;
                    arrayDatas.push_back(buf);
                }
            }
            fclose(fpIndex);
        } else
        {
            printf("Can not open %s\n", strPath.toStdString().c_str());
            mylog(L_ERR, "Can not open %s\n", strPath.toStdString().c_str());
        }
    }//end for

    return arrayDatas.join("|");
}

QString GmData::getIndexPhpPage(const QString & strIndexPath, uint32 start, uint32 end)
{
    //Php::Value arrayDatas;
    QStringList arrayDatas;

//    size_t numParam = params.size();
//    if (numParam != 3)
//        return arrayDatas;

    char indexpath[MAX_PATH] = {0};
    strcpy(indexpath, strIndexPath.toStdString().c_str());
    MYTIME_T st = static_cast<MYTIME_T>(start);
    MYTIME_T et = static_cast<MYTIME_T>(end);
    printf("%s %u %u\n", indexpath, st, et);

    char szIndexPath[MAX_PATH] = {0};
    strcpy(szIndexPath, indexpath);

    uint32 histno = 0;
    uint32 sn = 0;
    QList<QString> strDateList = HistoryDataHelper::getReginIndexFilesDate(st, et, indexpath);
    for (int i=0; i<strDateList.size(); i++)
    {
        QString strPath = szIndexPath + QString("/")+strDateList.at(i);//file ab path
        if (!QFile::exists(strPath))
        {
            mylog(L_ERR, "file %s not exist\n", strPath.toStdString().c_str());
            continue;
        }

        MYTIME_T theTime = 0;
        uint32   pos     = 0;
        FILE* fpIndex = NULL;
        char buf[1024] = {0};

        if (!fopen_s(&fpIndex, strPath.toStdString().c_str(), "rb"))
        {
            bool good = true;

            while(good)
            {
                if (good)
                    good = (1 == fread(&theTime, sizeof(MYTIME_T), 1, fpIndex));
                if (good)
                    good = (1 == fread(&pos    , sizeof(uint32)  , 1, fpIndex));

                if (theTime < st|| theTime > et || st > et)
                    continue;

                if (good)
                {
                    struct tm lt;
                    {
                        time_t t = (time_t)theTime;
                        localtime_s(&lt, &t);
                    }

                    ++sn;
                    _snprintf_s(buf, 1024, _TRUNCATE, "%d-%d-%d %d:%d:%d", lt.tm_year + 1900,
                                lt.tm_mon + 1,
                                lt.tm_mday,
                                lt.tm_hour,
                                lt.tm_min,
                                lt.tm_sec);

                    //Php::Value stat;
                    QStringList stat;
                    //stat[0] = buf;
                    stat.push_back(buf);
                    _snprintf_s(buf, 1024, _TRUNCATE, "%u", pos);
                    //stat[1] = buf;
                    stat.push_back(buf);

                    //arrayDatas[histno++] = stat;
                    arrayDatas.push_back(stat.join("|"));
                }
            }
            fclose(fpIndex);
        } else
        {
            printf("Can not open %s\n", strPath.toStdString().c_str());
            mylog(L_ERR, "Can not open %s\n", strPath.toStdString().c_str());
        }
    }//end for

    return arrayDatas.join("|");
}

QString GmData::readStatus(const QString &strConfigPath, const QString &strSharedKey,
                           const QStringList& keysList,
                           const QStringList &countList)
{
    //Php::Value arrayDatas;
    QStringList arrayDatas;

//    size_t numParam = params.size();
//    if (numParam != 7)
//        return arrayDatas;

    int kkk = 0;
    //size_t i = 0;
    {
        char config_path[MAX_PATH] = {0};
        strcpy(config_path, strConfigPath.toStdString().c_str());
        char ttttt[MAX_PATH];
        strcpy_s(ttttt, MAX_PATH, config_path);
        ConfigParser* parser = new ConfigParser;
        gconfig = parser->ParseJson(ttttt);
        delete parser;

        QTextStream(stdout) << config_path << "\n";
        if (!gconfig) {
            printf("ERROR parse config -- lll %s\n", ttttt);
            arrayDatas.push_back(QString("ERROR parse config -- lll %1\n").arg(ttttt));
            return arrayDatas.join("|");
        }

        //i = 1;
        char shared_key[512] = {0};
        strcpy(shared_key, strSharedKey.toStdString().c_str());
        strcpy_s(ttttt, MAX_PATH, shared_key);
        uint32 num = static_cast<uint32>(keysList.length());
        printf("%s %u %u\n", ttttt, num, (uint32)strlen(ttttt));
        //QByteArray ba(shared_key);
        //QString sk(ba);
        QSharedMemory sm(ttttt);
        if (!sm.attach()) {
            printf("haha Open %s error %s\n",
                   //sk.toStdString().c_str(),
                   ttttt,
                   sm.errorString().toStdString().c_str());
            arrayDatas.push_back(QString("haha Open %1 error %2\n").arg(ttttt)
                                 .arg(sm.errorString().toStdString().c_str()));
            free_config(&gconfig);
            return arrayDatas.join("|");
        } else {
            printf("Attached %s OK!\n", ttttt);
        }

        char *buf = (char*)sm.data();
        //size_t buflen = sm.size();
        char* ptr = buf;

        for (size_t acq_no = 0; acq_no < gconfig->acquisitor.size(); ++acq_no) {
            ConfigTransmitter* ct = gconfig->acquisitor.at(acq_no);
            if (_stricmp(ct->libpath, "/home/yanqi/projects/gm/bin/libHls_Modbus_Sp.so.1.0.0")) {
                TcpipServiceParam* tsp = (TcpipServiceParam*)ct->trans_param;
                for (size_t i = 0; i < tsp->tcpip_param.size(); ++i, ++kkk) {
                    TCPIP_STATUS* status = (TCPIP_STATUS*)ptr;

                    char timebuf[64];
                    {
                        time_t t = (time_t)status->LastAction;
                        struct tm* tt2 = localtime(&t);

                        _snprintf_s(timebuf, 64, _TRUNCATE,
                                    "%04d-%02d-%02d %02d:%02d:%02d",
                                    tt2->tm_year + 1900,
                                    tt2->tm_mon + 1,
                                    tt2->tm_mday,
                                    tt2->tm_hour,
                                    tt2->tm_min,
                                    tt2->tm_sec);
                    }

                    //Php::Value stat;
                    QStringList stat;
                    //stat[0] = status->Name;
                    stat.push_back(status->Name);
                    //stat[1] = Php::Value((int32_t)status->Port);
                    stat.push_back(QString::number((int32_t)status->Port));
                    //stat[2] = Php::Value((status->TcpipType == TCPIP_TYPE_UDP) ? "UDP" : "TCP");
                    stat.push_back((status->TcpipType == TCPIP_TYPE_UDP) ? "UDP" : "TCP");
                    //stat[3] = Php::Value((status->DirType == COMM_DIRECTION_TYPE_RECEIVED) ? "IN" : "OUT");
                    stat.push_back((status->DirType == COMM_DIRECTION_TYPE_RECEIVED) ? "IN" : "OUT");
                    //stat[4] = Php::Value(timebuf);
                    stat.push_back(timebuf);
                    //stat[5] = Php::Value((int32_t)((MYTIME_T)time(0) - status->LastAction));
                    stat.push_back(QString::number((int32_t)((MYTIME_T)time(0) - status->LastAction)));
                    //stat[6] = Php::Value((int32_t)status->InBytes );
                    stat.push_back(QString::number((int32_t)status->InBytes));
                    bool good = ((MYTIME_T)time(0) - status->LastAction > 60 * 10) ? false : true;
                    //stat[7] = Php::Value((good) ? "GOOD" : "BAD");
                    stat.push_back((good) ? "GOOD" : "BAD");
                    //stat[8] = Php::Value((int32_t)status->OutBytes);
                    stat.push_back(QString::number((int32_t)status->OutBytes));
                    //stat[9] = Php::Value((good) ? "GOOD" : "BAD");
                    stat.push_back((good) ? "GOOD" : "BAD");
                    arrayDatas.push_back(stat.join("|"));

                    //arrayDatas[kkk] = stat;

                    ptr = (char*)status + sizeof(TCPIP_STATUS);
                }
            } else {
                SerialPortServiceParam* sps = (SerialPortServiceParam*)ct->trans_param;
                for (size_t i = 0; i < sps->serial_param.size(); ++i, ++kkk) {
                    SERIAL_PORT_STATUS* status = (SERIAL_PORT_STATUS*)ptr;

                    char timebuf[64];
                    {
                        time_t t = (time_t)status->LastAction;
                        struct tm* tt2 = localtime(&t);

                        _snprintf_s(timebuf, 64, _TRUNCATE,
                                    "%04d-%02d-%02d %02d:%02d:%02d",
                                    tt2->tm_year + 1900,
                                    tt2->tm_mon + 1,
                                    tt2->tm_mday,
                                    tt2->tm_hour,
                                    tt2->tm_min,
                                    tt2->tm_sec);
                    }

//                    Php::Value stat;
//                    stat[0] = status->Name;
//                    stat[1] = Php::Value("9600, 8-N-1");
//                    stat[2] = Php::Value("Serial Port");
//                    stat[3] = Php::Value((status->DirType == COMM_DIRECTION_TYPE_RECEIVED) ? "IN" : "OUT");
//                    stat[4] = Php::Value(timebuf);
//                    stat[5] = Php::Value((int32_t)((MYTIME_T)time(0) - status->LastAction));
//                    stat[6] = Php::Value((int32_t)status->InBytes );
//                    bool good = ((MYTIME_T)time(0) - status->LastAction > 60 * 10) ? false : true;
//                    stat[7] = Php::Value((good) ? "GOOD" : "BAD");
//                    stat[8] = Php::Value((int32_t)status->OutBytes);
//                    stat[9] = Php::Value((good) ? "GOOD" : "BAD");

                    QStringList stat;
                    stat.push_back(status->Name);
                    stat.push_back("9600, 8-N-1");
                    stat.push_back("Serial Port");
                    stat.push_back(status->DirType == COMM_DIRECTION_TYPE_RECEIVED) ? "IN" : "OUT");
                    stat.push_back(timebuf);
                    stat.push_back(QString::number((int32_t)((MYTIME_T)time(0) - status->LastAction)));
                    stat.push_back(QString::number((int32_t)status->InBytes));
                    bool good = ((MYTIME_T)time(0) - status->LastAction > 60 * 10) ? false : true;
                    stat.push_back((good) ? "GOOD" : "BAD");
                    stat.push_back(QString::number((int32_t)status->OutBytes));
                    stat.push_back((good) ? "GOOD" : "BAD");

                    arrayDatas.push_back(stat.join("|"));
                    //arrayDatas[kkk] = stat;

                    ptr = (char*)status + sizeof(SERIAL_PORT_STATUS);
                }
            }
        }

        sm.detach();
        free_config(&gconfig);
    }

    char shared_key[512] = {0};
    for (int i = 0; i <keysList.length() && i<countList.length(); i++) {
        memset(shared_key, 0, sizeof(shared_key));
        strcpy(shared_key, keysList.at(i).c_str());
        char ttttt[MAX_PATH];
        strcpy_s(ttttt, MAX_PATH, shared_key);
        uint32 num = static_cast<uint32>(countList.at(i).toUInt());
        printf("%s %u %u\n", ttttt, num, (uint32)strlen(ttttt));
        //QByteArray ba(shared_key);
        //QString sk(ba);
        QSharedMemory sm(ttttt);
        if (!sm.attach()) {
            printf("haha Open %s error %s\n",
                   //sk.toStdString().c_str(),
                   ttttt,
                   sm.errorString().toStdString().c_str());
            arrayDatas.push_back(QString("haha Open %1 error %2\n").arg(ttttt).arg(sm.errorString().toStdString().c_str()));
            return arrayDatas.join("|");
        } else {
            printf("Attached %s OK!\n", ttttt);
        }

        char *buf = (char*)sm.data();
        size_t buflen = sm.size();

        if (num > buflen / sizeof(TCPIP_STATUS)
                || buflen % sizeof(TCPIP_STATUS)) {
            printf("Wrong num\n");
            sm.detach();
            return arrayDatas.join("|");
        }

        TCPIP_STATUS* status = (TCPIP_STATUS*)buf;

        for (uint32 i = 0; i < num; ++i, ++status) {
            //printf_tcpip_status(ts);

            char timebuf[64];
            {
                time_t t = (time_t)status->LastAction;
                struct tm* tt2 = localtime(&t);

                _snprintf_s(timebuf, 64, _TRUNCATE,
                            "%04d-%02d-%02d %02d:%02d:%02d",
                            tt2->tm_year + 1900,
                            tt2->tm_mon + 1,
                            tt2->tm_mday,
                            tt2->tm_hour,
                            tt2->tm_min,
                            tt2->tm_sec);
            }

//            Php::Value stat;
//            stat[0] = status->Name;
//            stat[1] = Php::Value((int32_t)status->Port);
//            stat[2] = Php::Value((status->TcpipType == TCPIP_TYPE_UDP) ? "UDP" : "TCP");
//            stat[3] = Php::Value((status->DirType == COMM_DIRECTION_TYPE_RECEIVED) ? "IN" : "OUT");
//            stat[4] = Php::Value(timebuf);
//            stat[5] = Php::Value((int32_t)((MYTIME_T)time(0) - status->LastAction));
//            stat[6] = Php::Value((int32_t)status->InBytes );
//            bool good = ((MYTIME_T)time(0) - status->LastAction > 60 * 10) ? false : true;
//            stat[7] = Php::Value((good) ? "GOOD" : "BAD");
//            stat[8] = Php::Value((int32_t)status->OutBytes);
//            stat[9] = Php::Value((good) ? "GOOD" : "BAD");

            QStringList stat;
            stat.push_back(status->Name);
            stat.push_back(QString::number(int32_t)status->Port);
            stat.push_back((status->TcpipType == TCPIP_TYPE_UDP) ? "UDP" : "TCP");
            stat.push_back((status->DirType == COMM_DIRECTION_TYPE_RECEIVED) ? "IN" : "OUT");
            stat.push_back(timebuf);
            stat.push_back(QString::number(((int32_t)((MYTIME_T)time(0) - status->LastAction)));
            stat.push_back(QString::number((int32_t)status->InBytes));
            bool good = ((MYTIME_T)time(0) - status->LastAction > 60 * 10) ? false : true;
            stat.push_back((good) ? "GOOD" : "BAD");
            stat.push_back(QString::number((int32_t)status->OutBytes));
            stat.push_back((good) ? "GOOD" : "BAD");

            //arrayDatas[kkk++] = stat;
            arrayDatas.puahs_back(stat.join("|")));
        }
        sm.detach();
    }

    return arrayDatas.join("&");
}

QString GmData::readWarning(const QString &strIndexPath, uint32 start, uint32 end, const QString &strGroup)
{
//    Php::Value arrayDatas;
//    size_t numParam = params.size();
//    if (numParam != 4)
//    {
//        return arrayDatas;
//    }

    QStringList arrayDatas;

    char indexpath[MAX_PATH] = {0};
    strcpy(indexpath, strIndexPath.toStdString().c_str());
    MYTIME_T st = static_cast<MYTIME_T>(start);
    MYTIME_T et = static_cast<MYTIME_T>(end);
    char szGroup[20] = {0};
    strcpy(szGroup, strGroup.c_str());

    printf("%s %u %u %s\n", indexpath, st, et, szGroup);
    QString strIndexPath = QString(indexpath) + QString("/warningIndex");
    if (!QFile::exists(strIndexPath))
    {
        printf("file not exist %s !\n", strIndexPath.toStdString().c_str());
        //arrayDatas[0] = strIndexPath.toStdString().c_str();
        arrayDatas.push_back(strIndexPath.toStdString().c_str());
        return arrayDatas.join("|");
    }

    FILE* fp = fopen(strIndexPath.toStdString().c_str(), "rb");
    if (!fp)
    {
        printf("Can not open %s to read!\n", strIndexPath.toStdString().c_str());
        //arrayDatas[0] = "Can not open to read!\n!!!";
        arrayDatas.push_back("Can not open to read!\n!!!");
        return arrayDatas.join("|");
    }

    char szBuffer[1024];
    strucWarningData warningData;
    int nLen = 0;
    int nIndex = 0;
    while (sizeof(strucWarningData) == (nLen=fread(&warningData, 1, sizeof(strucWarningData), fp)))
    {
        char szTime[20];
        struct tm lt;
        {
            time_t t = (time_t)warningData.time;
            if (t < st || t > et)
            {
                continue;
            }

            localtime_s(&lt, &t);
        }

        sprintf(szTime, "%d-%d-%d %d:%d:%d",
                lt.tm_year + 1900,
                lt.tm_mon + 1,
                lt.tm_mday,
                lt.tm_hour,
                lt.tm_min,
                lt.tm_sec);
        if (warningData.data.datatype == POINT_DATATYPE_TYPE_ANALOG)
        {
            sprintf(szBuffer, "%s|%d|%d|%d|%f|%f|%f",
                    szTime,
                    warningData.nGroupNumber,
                    warningData.dataPos,
                    warningData.index,
                    warningData.data.data.fvalue,
                    warningData.dwMin,
                    warningData.dwMax);
        }
        else
        {
            sprintf(szBuffer, "%s|%d|%d|%d|%d|%f|%f",
                    szTime,
                    warningData.nGroupNumber,
                    warningData.dataPos,
                    warningData.index,
                    warningData.data.data.bvalue,
                    warningData.dwMin,
                    warningData.dwMax);
        }
        //arrayDatas[nIndex] = szBuffer;
        arrayDatas.push_back(szBuffer);
        nIndex++;
    }

    if (fp)
    {
        fclose(fp);
    }
    return arrayDatas.join("|");
}

QString GmData::readWarningDataToMemory(uint32 nPos, const QString &strHistFile)
{
    //Php::Value arrayDatas;
    QStringList arrayDatas;

//    size_t numParam = params.size();
//    if (numParam != 2)
//        return arrayDatas;
    uint32 pos = static_cast<uint32>(nPos);
    char histfile[MAX_PATH] = {0};
    strcpy(histfile, strHistFile.toStdString().c_str());

    char szHistFile[MAX_PATH] = {0};
    strcpy(szHistFile, histfile);

    QString strFileName = QString(szHistFile) + "/warningData";
    if(!QFile::exists(strFileName))
    {
        printf("file not exist %s !\n", strFileName.toStdString().c_str());
        arrayDatas.push_back(QString("file not exist %1 !\n").arg(strFileName));
        return arrayDatas.join("|");
    }

    FILE* fp = fopen(strFileName.toStdString().c_str(), "rb");
    if (!fp)
    {
        //printf("Can not open %s to read!\n", strFileName.toStdString().c_str());
        arrayDatas.push_back(QString("Can not open %1 to read!\n").arg(strFileName));
        return arrayDatas.join("|");
    }

    int result = fseek(fp, pos, SEEK_SET);
    //printf("RESULT %d\n", result);

    if (!result) {
        MYTIME_T tt;
        uint32 datanum;

        result = fread(&tt, sizeof(MYTIME_T), 1, fp);
        result = fread(&datanum, sizeof(uint32), 1, fp);

        printf("Pos %u Time %u Datanum %u\n",pos, tt, datanum);

        char tmp[64]={0};
        _snprintf_s(tmp, 64, _TRUNCATE, "%lu", tt);

        //arrayDatas[0] = tmp;
        arrayDatas.push_back(tmp);

        //arrayDatas[1]=length

        _snprintf_s(tmp, 64, _TRUNCATE, "%lu", datanum);
        //arrayDatas[1] = tmp;
        arrayDatas.push_back(QString::number(tmp));

        DataStructure* buf = new DataStructure[datanum];
        result = fread(buf, sizeof(DataStructure), datanum, fp);

        //char tmp[64];
        DataStructure* ds = buf;
        for (uint32 i = 0; i < datanum; ++i, ++ds) {
            if (ds->datatype == POINT_DATATYPE_TYPE_ANALOG)
                _snprintf_s(tmp, 64, _TRUNCATE, "%.02f", ds->data.fvalue);
            else
                _snprintf_s(tmp, 64, _TRUNCATE, "%d", ds->data.bvalue);
            arrayDatas[i+2] = tmp;
        }

        delete[] buf;
    }


    return arrayDatas.join("|");
}
